module.exports = {
    token: "replace with ur real token plz", // video tutorial: https://youtu.be/pqW553a3_Tc

    // Servers u want the bot to not catch anything in
    blacklistedServers: [
        "ServerNameOrID1",
        "ServerNameOrID2",
        "ServerNameOrID3"
    ],

    // Servers u want the bot to only catch there
    // This gargabe will be disabled if nothing in the list
    // You can replace it with "farmserver" aka if all your servers is named farmserver and that the server you want to farm in, then you can replace it so it does farm in all server named farmserver. You may edit it
    whitelistedServers: [
        "ServerNameOrID1",
        "ServerNameOrID2",
        "ServerNameOrID3"
    ],

    // the Server u want the bot to send a message every hour to
    // This garbage will be disabled if nothing in the list
    // You can replace it with "farmserver" aka if all your servers is named farmserver and that the server you want to farm in, then you can replace it so it does farm in all server named farmserver. You may edit it
    farmServers: [
        "ServerNameOrID1",
        "ServerNameOrID2",
        "ServerNameOrID3"
    ],

    // this field is used to get a channel from the farm servers using name (it will use the first channel if not provided)
    farmChannelName: 'general',
    // this cooldown is enforced after each message in guilds so the bot wouldn't get ratelimited (miliseconds)
    farmCooldown: [9000, 11000],
    // time to sleep after sending a message to all of the servers (miliseconds)
    farmSleepTime: 920000,

    // Extra wait time for clicking the button on ballsdex balls
    timeout: [500, 1000],

    // Dashboard: we have a website with a dashboard that u can create an account on and see all of the balls caught by u and autocatcher
    // the stored information is not available to public and wont be shared with anyone
    dashboardToken: '', // obtainable from autocatcher.xyz - leave empty if u dont need it
}
