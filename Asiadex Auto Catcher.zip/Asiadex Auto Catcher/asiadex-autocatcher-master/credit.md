Thank you SextyNine for making the original verison

and credit to him.